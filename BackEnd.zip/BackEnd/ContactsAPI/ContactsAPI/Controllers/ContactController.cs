﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ContactsAPI.Models;

namespace ContactsAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContactController : ControllerBase
    {
        private readonly ContactDbContext _contactDbContext;

        public ContactController(ContactDbContext contactDbContext)
        {
            _contactDbContext = contactDbContext;
        }

        [HttpGet]
        [Route("GetContact")]
        public async Task<IEnumerable<Contact>> GetContact()
        {
            return await _contactDbContext.Contact.ToListAsync();
        }

        [HttpPost]
        [Route("AddContact")]
        public async Task<Contact> AddContact(Contact objContact)
        {
            _contactDbContext.Contact.Add(objContact);
            await _contactDbContext.SaveChangesAsync();
            return objContact;
        }

        [HttpPatch]
        [Route("UpdateContact/{id}")]
        public async Task<Contact> UpdateContact(Contact objContact)
        {
            _contactDbContext.Entry(objContact).State = EntityState.Modified;
            await _contactDbContext.SaveChangesAsync();
            return objContact;
        }

        [HttpDelete]
        [Route("DeleteContact/{id}")]
        public bool DeleteContact(int id)
        {
            bool a = false;
            var contact = _contactDbContext.Contact.Find(id);
            if (contact != null)
            {
                a = true;
                _contactDbContext.Entry(contact).State = EntityState.Deleted;
                _contactDbContext.SaveChanges();
            }
            else
            {
                a = false;
            }
            return a;

        }

    }

}