﻿using System;
using Microsoft.EntityFrameworkCore;

namespace ContactsAPI.Models
{
	public class ContactDbContext: DbContext
	{
        public ContactDbContext(DbContextOptions<ContactDbContext> options) : base(options)
        {
        }

        public DbSet<Contact> Contact { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("ContactDbContext");
        }
    }
}

